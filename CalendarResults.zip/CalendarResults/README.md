# Exam Results Dashboard PWA

A Progressive Web App for viewing student exam results and analytics.

## Features
- Responsive design
- Offline capability
- Installable on mobile devices
- Real-time analytics visualization

## Deployment (Vercel Static Hosting)

1. Ensure all your static files (HTML, CSS, JS, images, manifest, sw.js) are in the `/public` folder.
2. Your `index.html` must be in `/public` (not in the root).
3. The `vercel.json` file should be in the project root and should NOT specify `outputDirectory` or `public` properties for static hosting.
4. Deploy the root folder (`CalendarResults`) to Vercel.
5. In the Vercel dashboard, leave the build command blank and the output directory blank (or set to `public` if required).
6. Your site will be served from `/public/index.html` at the root URL.

### Project Structure Example

```
CalendarResults/
├── public/
│   ├── index.html
│   ├── css/
│   ├── js/
│   ├── images/
│   ├── manifest.json
│   └── sw.js
├── vercel.json
└── README.md
```

If you see a 404 error, make sure you are visiting the root URL and that your static files are inside `/public`.
